---
excerpt: 自动生成的摘要
title: 一个清新的wp主题与两个blogger主题
tags:
  - wp与blogger主题
id: '111'
categories:
  - - wordpress主题与插件
date: 2025-06-10 19:28:45
---
excerpt: 自动生成的摘要

一个清新的wp主题与两个blogger主题: 清新的wp主题是Iconic One Tme 两个blogger主题一个是median ui blogger template 一个是Contempo ，Contempo在Blogger 官方内置主题有，当然，Soho / Emporio /Notable 这几个也不错，也在Blogger 官方内置。