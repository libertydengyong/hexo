---
excerpt: 自动生成的摘要
title: 一个轻量级 Xray 面板
tags:
  - 轻量级 Xray 面板
id: '137'
categories:
  - - vps工具
date: 2025-07-09 12:32:25
---
excerpt: 自动生成的摘要

**轻量级 Xray 面板** bash <(curl -Ls https://raw.githubusercontent.com/FranzKafkaYu/x-ui/master/install.sh)   项目来源:   https://github.com/FranzKafkaYu/x-ui?tab=readme-ov-file#%E4%B8%80%E9%94%AE%E5%AE%89%E8%A3%85