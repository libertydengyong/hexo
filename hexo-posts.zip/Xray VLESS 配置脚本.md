---
excerpt: 自动生成的摘要
title: Xray VLESS 配置脚本
date: 2026-01-17 17:34:00
tags:
---
excerpt: 自动生成的摘要

一键:

bash <(curl -sL https://raw.githubusercontent.com/audsiui/xray-jb/main/main.sh)


来源:
https://github.com/audsiui/xray-jb
