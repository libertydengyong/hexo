---
excerpt: 自动生成的摘要
title: 一键更换为XanMod内核
tags:
  - XanMod内核
id: '41'
categories:
  - - vps工具
date: 2025-05-07 21:39:51
---
excerpt: 自动生成的摘要

wget -O [tcpx.sh](https://draft.blogger.com/blog/page/edit/6572730579278366385/7941114663552175576#) "[https://github.com/ylx2016/Linux-NetSpeed/raw/master/tcpx.sh](https://draft.blogger.com/blog/page/edit/6572730579278366385/7941114663552175576#)" && chmod +x [tcpx.sh](https://draft.blogger.com/blog/page/edit/6572730579278366385/7941114663552175576#) && ./tcpx.sh