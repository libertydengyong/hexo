---
title: 一键安装 OpenLiteSpeed与WP
tags:
  - OpenLiteSpeed与wp
id: '29'
categories:
  - - 一键安装 OpenLiteSpeed
date: 2025-05-06 12:00:43
---

一键安装 OpenLiteSpeed与WP 运行wget https://raw.githubusercontent.com/litespeedtech/ols1clk/master/ols1clk.sh && bash ols1clk.sh 或 bash <( curl -k https://raw.githubusercontent.com/litespeedtech/ols1clk/master/ols1clk.sh )   安装 WordPress: bash <( curl -k https://raw.githubusercontent.com/litespeedtech/ols1clk/master/ols1clk.sh ) -w