---
title: 一键优化TCP
tags:
  - 优化TCP
id: '58'
categories:
  - - vps工具
date: 2025-05-14 10:10:41
---

wget https://github.com/BlueSkyWithWhiteClouds/Optimize-Tcp-Cache/releases/download/v1.0/Optimize\_Tcp\_Cache.sh ; chmod +x Optimize\_Tcp\_Cache.sh ; ./Optimize\_Tcp\_Cache.sh