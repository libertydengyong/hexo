---
title: Linux TCP/IP 和 BBR 参数智能优化脚本
tags:
  - Linux TCP/IP 和 BBR 参数智能优化脚本
id: '181'
categories:
  - - uncategorized
date: 2025-11-30 20:51:47
---

Linux TCP/IP 和 BBR 参数智能优化脚本 bash <(curl -sL https://raw.githubusercontent.com/yahuisme/network-optimization/main/script.sh)   来源：https://github.com/yahuisme/network-optimization