---
title: VPS一键系统管理
tags:
  - VPS一键系统管理
id: '177'
categories:
  - - vps工具
date: 2025-11-25 15:47:13
---

VPS一键系统管理： bash <(curl -sL sh.cici.one)   只支持DEBIAN,ubuntu系统