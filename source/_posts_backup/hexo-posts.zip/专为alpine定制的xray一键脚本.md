---
excerpt: 自动生成的摘要
title: 专为alpine定制的Xray一键脚本
tags:
  - Xray一键脚本
id: '134'
categories:
  - - vps技巧
date: 2025-07-01 15:45:48
---
excerpt: 自动生成的摘要

专为alpine定制的Xray一键脚本 wget https://raw.githubusercontent.com/miku111/XrayOnAlpine/main/install-release.sh && bash install-release.sh 或curl -L -s https://raw.githubusercontent.com/miku111/XrayOnAlpine/main/install-release.sh bash 启动Xray:    sudo service xray start 项目来源https://github.com/miku111/XrayOnAlpine