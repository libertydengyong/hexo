---
title: S-UI面板搭建
tags:
  - S-UI面板搭建
id: '174'
categories:
  - - vps技巧
date: 2025-11-17 16:25:54
---

S-UI面板搭建： bash <(curl -Ls https://raw.githubusercontent.com/alireza0/s-ui/master/install.sh) 项目地址：https://github.com/alireza0/s-ui