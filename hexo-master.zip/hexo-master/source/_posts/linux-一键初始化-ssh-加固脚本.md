---
title: Linux 一键初始化 & SSH 加固脚本
tags:
  - Linux 一键初始化 &amp; SSH 加固脚本
id: '184'
categories:
  - - vps技巧
date: 2025-12-12 21:12:01
---

Linux 一键初始化 & SSH 加固脚本 curl -fsSL https://raw.githubusercontent.com/247like/linux-ssh-init-sh/main/init.sh -o init.sh && chmod +x init.sh && ./init.sh   来源：https://github.com/247like/linux-ssh-init-sh