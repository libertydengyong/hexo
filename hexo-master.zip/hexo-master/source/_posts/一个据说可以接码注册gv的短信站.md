---
title: 一个据说可以接码注册GV的短信站
tags:
  - 注册GV
id: '192'
categories:
  - - uncategorized
date: 2025-12-31 16:17:40
---

一个据说可以接码注册GV的短信站 https://www.smspool.net/   还有这两个据说也可以 https://sms-bus.com https://daisysms.com