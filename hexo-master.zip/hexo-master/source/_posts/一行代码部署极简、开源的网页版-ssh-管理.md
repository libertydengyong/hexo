---
title: "一行代码部署极简、开源的网页版 SSH\_管理:"
tags:
  - "网页版 SSH\_管理"
id: '159'
categories:
  - - vps技巧
date: 2025-07-28 12:36:20
---

一行代码部署极简、开源的**网页版 SSH** 管理: docker run -d --network host hochenggang/managi:0.5.0 访问 http://IP:18001